// jshint esversion: 6

const hasTouch = 'ontouchstart' in window || navigator.msMaxTouchPoints;

export default {
    hasTouch
};
